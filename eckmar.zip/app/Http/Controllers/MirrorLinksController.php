<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MirrorLinksController extends Controller
{
    //
}
